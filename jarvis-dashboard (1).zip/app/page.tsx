import { JarvisDashboard } from "@/components/jarvis-dashboard"

export default function HomePage() {
  return <JarvisDashboard />
}

"use client"

import { useState, useEffect, useRef, useCallback } from "react"
import { Button } from "@/components/ui/button" // Assuming shadcn/ui Button is available

export function JarvisDashboard() {
  const [recognizedText, setRecognizedText] = useState<string>("")
  const [isListening, setIsListening] = useState<boolean>(false)
  const [speechRecognition, setSpeechRecognition] = useState<any | null>(null)

  // Refs for audio visualization
  const audioContextRef = useRef<AudioContext | null>(null)
  const analyserRef = useRef<AnalyserNode | null>(null)
  const dataArrayRef = useRef<Uint8Array | null>(null)
  const bufferLengthRef = useRef<number>(0)
  const canvasRef = useRef<HTMLCanvasElement | null>(null)
  const canvasCtxRef = useRef<CanvasRenderingContext2D | null>(null)
  const animationFrameIdRef = useRef<number | null>(null)
  const mediaStreamRef = useRef<MediaStream | null>(null)

  // Initialize SpeechRecognition API
  useEffect(() => {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition
    if (SpeechRecognition) {
      const recognition = new SpeechRecognition()
      recognition.continuous = false
      recognition.interimResults = false
      recognition.lang = "en-US"

      recognition.onresult = (event) => {
        const speechResult = event.results[0][0].transcript
        setRecognizedText(`You said: "${speechResult}"`)
        console.log("Speech recognized:", speechResult)
      }

      recognition.onerror = (event) => {
        setRecognizedText(`Error: ${event.error}`)
        console.error("Speech recognition error:", event.error)
        setIsListening(false)
        stopVisualizer()
      }

      recognition.onend = () => {
        setIsListening(false)
        stopVisualizer()
        // Clear recognized text after a short delay if no new input
        setTimeout(() => {
          if (!isListening && recognizedText.startsWith("You said:")) {
            setRecognizedText("")
          }
        }, 5000)
      }

      setSpeechRecognition(recognition)
    } else {
      console.warn("Speech Recognition is not supported in this browser.")
    }

    // Cleanup on unmount
    return () => {
      if (speechRecognition) {
        speechRecognition.stop()
      }
      stopVisualizer()
    }
  }, [isListening, recognizedText, speechRecognition]) // Dependencies for useEffect

  // Function to draw the audio visualizer
  const drawVisualizer = useCallback(() => {
    if (!canvasCtxRef.current || !analyserRef.current || !dataArrayRef.current || !bufferLengthRef.current) {
      return
    }

    animationFrameIdRef.current = requestAnimationFrame(drawVisualizer)

    analyserRef.current.getByteTimeDomainData(dataArrayRef.current)

    const canvas = canvasRef.current
    const canvasCtx = canvasCtxRef.current
    const dataArray = dataArrayRef.current
    const bufferLength = bufferLengthRef.current

    if (!canvas || !canvasCtx) return

    canvasCtx.clearRect(0, 0, canvas.width, canvas.height)
    canvasCtx.lineWidth = 2
    canvasCtx.strokeStyle = "rgba(0, 255, 255, 0.8)" // Cyan glow

    canvasCtx.beginPath()

    const sliceWidth = (canvas.width * 1.0) / bufferLength
    let x = 0

    for (let i = 0; i < bufferLength; i++) {
      const v = dataArray[i] / 128.0
      const y = (v * canvas.height) / 2

      if (i === 0) {
        canvasCtx.moveTo(x, y)
      } else {
        canvasCtx.lineTo(x, y)
      }

      x += sliceWidth
    }

    canvasCtx.lineTo(canvas.width, canvas.height / 2)
    canvasCtx.stroke()
  }, [])

  // Function to start the audio visualizer
  const startVisualizer = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true })
      mediaStreamRef.current = stream

      audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)()
      analyserRef.current = audioContextRef.current.createAnalyser()
      analyserRef.current.fftSize = 2048 // Adjust for more or less detail
      bufferLengthRef.current = analyserRef.current.frequencyBinCount
      dataArrayRef.current = new Uint8Array(bufferLengthRef.current)

      const source = audioContextRef.current.createMediaStreamSource(stream)
      source.connect(analyserRef.current)
      // analyserRef.current.connect(audioContextRef.current.destination); // Connect to speakers for monitoring (optional)

      const canvas = canvasRef.current
      if (canvas) {
        canvasCtxRef.current = canvas.getContext("2d")
        canvas.style.opacity = "1" // Make canvas visible
        drawVisualizer()
      }
    } catch (err) {
      console.error("Error accessing microphone:", err)
      alert("Could not access microphone. Please ensure it's connected and permissions are granted.")
      setIsListening(false)
      stopVisualizer()
    }
  }

  // Function to stop the audio visualizer
  const stopVisualizer = () => {
    if (animationFrameIdRef.current) {
      cancelAnimationFrame(animationFrameIdRef.current)
      animationFrameIdRef.current = null
    }
    if (audioContextRef.current) {
      audioContextRef.current.close().then(() => {
        audioContextRef.current = null
        analyserRef.current = null
        dataArrayRef.current = null
        bufferLengthRef.current = 0
        canvasCtxRef.current = null
      })
    }
    if (mediaStreamRef.current) {
      mediaStreamRef.current.getTracks().forEach((track) => track.stop())
      mediaStreamRef.current = null
    }
    if (canvasRef.current) {
      canvasRef.current.style.opacity = "0" // Hide canvas
    }
  }

  const handleSpeak = () => {
    if ("speechSynthesis" in window) {
      const textToSpeak = document.getElementById("main-subtext")?.textContent || ""
      const utterance = new SpeechSynthesisUtterance(textToSpeak)
      utterance.lang = "en-US"
      utterance.pitch = 1
      utterance.rate = 1
      window.speechSynthesis.speak(utterance)
    } else {
      alert("Speech Synthesis is not supported in your browser.")
    }
  }

  const handleListen = () => {
    if (speechRecognition) {
      setIsListening(true)
      setRecognizedText("Listening...")
      startVisualizer() // Start visualizer before recognition
      speechRecognition.start()
    } else {
      alert(
        "Speech Recognition is not supported or enabled in your browser. Please use Chrome or Edge and ensure microphone access.",
      )
    }
  }

  return (
    <div className="relative flex min-h-screen flex-col items-center justify-center p-5 font-orbitron text-jarvis-cyan">
      {/* Header Left */}
      <div className="absolute left-5 top-5 p-2 text-left md:left-10 md:top-10">
        <h1 className="text-3xl font-bold text-jarvis-cyan drop-shadow-[0_0_5px_#00ffff] md:text-4xl lg:text-5xl">
          J.A.R.V.I.S.
        </h1>
        <p className="font-mono text-sm text-jarvis-cyan-dark drop-shadow-[0_0_3px_#00e6e6] md:text-base">
          Just A Rather Very Intelligent System
        </p>
      </div>

      {/* Header Right Buttons */}
      <div className="absolute right-5 top-5 flex gap-3 p-2 md:right-10 md:top-10 md:gap-5">
        <Button
          className="border-2 border-jarvis-button-green bg-transparent px-4 py-2 font-orbitron text-jarvis-cyan shadow-[0_0_8px_#00ff00,0_0_15px_#00ff00_inset] transition-all duration-300 hover:scale-105 hover:bg-jarvis-cyan/10 hover:shadow-[0_0_15px_#00ff00,0_0_25px_#00ff00]"
          variant="outline"
        >
          Test AI
        </Button>
        <Button
          className="border-2 border-jarvis-button-orange bg-transparent px-4 py-2 font-orbitron text-jarvis-cyan shadow-[0_0_8px_#ffa500,0_0_15px_#ffa500_inset] transition-all duration-300 hover:scale-105 hover:bg-jarvis-cyan/10 hover:shadow-[0_0_15px_#ffa500,0_0_25px_#ffa500]"
          variant="outline"
        >
          Test Search
        </Button>
        <Button
          className="border-2 border-jarvis-button-purple bg-transparent px-4 py-2 font-orbitron text-jarvis-cyan shadow-[0_0_8px_#8a2be2,0_0_15px_#8a2be2_inset] transition-all duration-300 hover:scale-105 hover:bg-jarvis-cyan/10 hover:shadow-[0_0_15px_#8a2be2,0_0_25px_#8a2be2]"
          variant="outline"
        >
          Activate
        </Button>
      </div>

      {/* Main Content - AI Face and Text */}
      <div className="flex flex-col items-center text-center">
        {/* AI Face Container */}
        <div
          className="relative mb-5 flex h-64 w-64 items-center justify-center rounded-full border-2 border-jarvis-cyan bg-jarvis-cyan/5 shadow-jarvis-cyan animate-pulse-glow
                     md:h-72 md:w-72 lg:h-80 lg:w-80"
        >
          {/* Left Eye */}
          <div className="absolute left-1/4 top-1/3 h-8 w-8 rounded-full bg-jarvis-cyan shadow-[0_0_10px_#00ffff,0_0_20px_#00ffff] animate-eye-blink md:h-10 md:w-10"></div>
          {/* Right Eye */}
          <div className="absolute right-1/4 top-1/3 h-8 w-8 rounded-full bg-jarvis-cyan shadow-[0_0_10px_#00ffff,0_0_20px_#00ffff] animate-eye-blink md:h-10 md:w-10"></div>
          {/* Mouth */}
          <div className="absolute bottom-1/4 h-1 w-24 rounded-sm bg-jarvis-cyan shadow-[0_0_8px_#00ffff,0_0_15px_#00ffff] md:w-32"></div>
        </div>

        {/* Status Text */}
        <p className="mb-10 font-mono text-xl text-jarvis-cyan drop-shadow-[0_0_5px_#00ffff] animate-text-flicker md:text-2xl">
          ONLINE
        </p>

        {/* Main Headline */}
        <h2 className="mb-4 text-4xl font-bold text-jarvis-cyan drop-shadow-[0_0_10px_#00ffff,0_0_20px_#00ffff] animate-slide-in-1s md:text-5xl lg:text-6xl">
          JARVIS Interface Active
        </h2>
        {/* Subtitle */}
        <p
          id="main-subtext"
          className="mb-10 font-mono text-lg text-jarvis-cyan-dark drop-shadow-[0_0_5px_#00e6e6] animate-slide-in-1-2s md:text-xl lg:text-2xl"
        >
          Say ‘JARVIS search for latest tech news’ to see the LIVE browser search!
        </p>
      </div>

      {/* Bottom Section - Input and Speech Buttons */}
      <div className="flex w-full max-w-3xl flex-col items-center gap-5 p-5">
        <input
          type="text"
          placeholder="Type your command here..."
          className="w-full rounded-md border-2 border-jarvis-cyan bg-jarvis-dark-bg p-3 font-mono text-lg text-jarvis-cyan outline-none transition-all duration-300 focus:shadow-[0_0_15px_#00ffff] focus:ring-0"
        />
        <div className="flex flex-wrap justify-center gap-5">
          <Button
            onClick={handleSpeak}
            className="min-w-[150px] flex-1 border-2 border-jarvis-cyan bg-jarvis-cyan/10 px-6 py-3 font-orbitron text-xl text-jarvis-cyan shadow-[0_0_10px_#00ffff,0_0_20px_#00ffff_inset] transition-all duration-300 hover:scale-105 hover:bg-jarvis-cyan/20 hover:shadow-[0_0_20px_#00ffff,0_0_30px_#00ffff_inset] disabled:cursor-not-allowed disabled:opacity-50"
            disabled={!("speechSynthesis" in window)}
          >
            🔊 Speak
          </Button>
          <Button
            onClick={handleListen}
            className="min-w-[150px] flex-1 border-2 border-jarvis-cyan bg-jarvis-cyan/10 px-6 py-3 font-orbitron text-xl text-jarvis-cyan shadow-[0_0_10px_#00ffff,0_0_20px_#00ffff_inset] transition-all duration-300 hover:scale-105 hover:bg-jarvis-cyan/20 hover:shadow-[0_0_20px_#00ffff,0_0_30px_#00ffff_inset] disabled:cursor-not-allowed disabled:opacity-50"
            disabled={isListening || !speechRecognition}
          >
            {isListening ? "🎙️ Listening..." : "🎙️ Listen"}
          </Button>
        </div>

        {/* Audio Visualizer Canvas */}
        <canvas
          ref={canvasRef}
          width="800"
          height="100"
          className="mt-5 w-full max-w-3xl rounded-md border border-jarvis-cyan/20 bg-black/30 transition-opacity duration-500"
          style={{ opacity: isListening ? 1 : 0 }} // Control visibility with state
        ></canvas>

        {/* Recognized Text Output */}
        <div
          className={`${recognizedText ? "opacity-100" : "opacity-0"} mt-5 min-h-[3rem] w-full max-w-3xl rounded-md border border-jarvis-cyan/20 bg-black/30 p-3 font-mono text-lg text-jarvis-cyan-dark transition-opacity duration-500`}
        >
          {recognizedText}
        </div>
      </div>
    </div>
  )
}

\
{
  Config
  \
}
from
;("tailwindcss")
\
const config = \
{
  darkMode: ["class"],\
  content: ["./pages/**/*.{ts,tsx}", "./components/**/*.{ts,tsx}", "./app/**/*.{ts,tsx}", "./src/**/*.{ts,tsx}", "*.{js,ts,jsx,tsx,mdx}"],\
  prefix: "",\
  theme:
  \
  container:
  \
  center: true,\
  padding: "2rem",\
  screens:
  \
  "2xl\": \"1400px",\
  \
  ,\
    \
  ,
    extend: \
  colors:
  \
  border: "hsl(var(--border))",\
  input: "hsl(var(--input))",\
  ring: "hsl(var(--ring))",\
  background: "hsl(var(--background))",\
  foreground: "hsl(var(--foreground))",\
  primary:
  \
  DEFAULT: "hsl(var(--primary))",\
  foreground: "hsl(var(--primary-foreground))",\
  \
  ,
        secondary: \
  DEFAULT: "hsl(var(--secondary))",\
  foreground: "hsl(var(--secondary-foreground))",\
  \
  ,
        destructive: \
  DEFAULT: "hsl(var(--destructive))",\
  foreground: "hsl(var(--destructive-foreground))",\
  \
  ,
        muted: \
  DEFAULT: "hsl(var(--muted))",\
  foreground: "hsl(var(--muted-foreground))",\
  \
  ,
        accent: \
  DEFAULT: "hsl(var(--accent))",\
  foreground: "hsl(var(--accent-foreground))",\
  \
  ,
        popover: \
  DEFAULT: "hsl(var(--popover))",\
  foreground: "hsl(var(--popover-foreground))",\
  \
  ,
        card: \
  DEFAULT: "hsl(var(--card))",\
  foreground: "hsl(var(--card-foreground))",\
  \
  ,
        // Custom JARVIS colors
        'jarvis-cyan': '#00ffff',
        'jarvis-cyan-dark': '#00e6e6',
        'jarvis-dark-bg': '#0a0a0a',
        'jarvis-grid-line': 'rgba(0, 255, 255, 0.1)',
        'jarvis-button-green': '#00ff00',
        'jarvis-button-orange': '#ffa500',
        'jarvis-button-purple': '#8a2be2',\
      \
  ,
      borderRadius: \
  lg: "var(--radius)", md
  : "calc(var(--radius) - 2px)",
        sm: "calc(var(--radius) - 4px)",
      \
  ,
      keyframes: \
  ;("accordion-down")
  : \
  from:
  \
  height: "0"
  \
  ,
          to: \
  height: "var(--radix-accordion-content-height)"
  \
  ,
        \
  ,
        "accordion-up": \
  from:
  \
  height: "var(--radix-accordion-content-height)"
  \
  ,
          to: \
  height: "0"
  \
  ,
        \
  ,
        // Custom JARVIS animations
        "pulse-glow": \
  ;("0%, 100%")
  : \
  ;("box-shadow")
  : "0 0 15px var(--tw-shadow-color), 0 0 30px var(--tw-shadow-color), 0 0 45px var(--tw-shadow-color)",
          \
  ,
          "50%": \
  ;("box-shadow")
  : "0 0 20px var(--tw-shadow-color), 0 0 40px var(--tw-shadow-color), 0 0 60px var(--tw-shadow-color)",
          \
  ,
        \
  ,
        "eye-blink": \
  ;("0%, 10%, 100%")
  : \
  transform: "scaleY(1)"
  \
  ,
          "5%": \
  transform: "scaleY(0.1)"
  \
  ,
        \
  ,
        "text-flicker": \
  ;("0%, 100%")
  : \
  opacity: "1"
  \
  ,
          "50%": \
  opacity: "0.8"
  \
  ,
        \
  ,
        "slide-in": \
  from:
  \
  opacity: "0", transform
  : "translateY(20px)" \
  ,
          to: \
  opacity: "1", transform
  : "translateY(0)" \
  ,
        \
  ,
        "grid-pulse": \
  ;("0%")
  : \
  ;("background-color")
  : "var(--jarvis-dark-bg)" \
  ,
          "100%": \
  ;("background-color")
  : "#050505" \
  ,
        \
  ,
      \
  ,
      animation: \
  ;("accordion-down")
  : "accordion-down 0.2s ease-out",
        "accordion-up": "accordion-up 0.2s ease-out",
        "pulse-glow": "pulse-glow 2s infinite alternate",
        "eye-blink": "eye-blink 4s infinite",
        "text-flicker": "text-flicker 1s infinite alternate",
        "slide-in-1s": "slide-in 1s ease-out forwards",
        "slide-in-1-2s": "slide-in 1.2s ease-out forwards",
        "grid-pulse": "grid-pulse 5s infinite alternate",
      \
  ,
      fontFamily: \
  orbitron: ["Orbitron", "sans-serif"], mono
  : ['Roboto Mono', 'monospace'],
      \
  ,
    \
  ,
  \
  ,
  plugins: [require("tailwindcss-animate")],
\
}
satisfies
Config

export default config
